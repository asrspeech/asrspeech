#!/usr/bin/python
# coding=utf8
import os
import re
import sys
import time
import smtplib
import socket
from email.Message import Message
from email.charset import Charset
from email.header import Header
import email
import traceback


def asrpFindLineByKey(file_content, key):
    """
    Find line in file,which contains the key
    :return:line
    """
    for line in file_content:
        if re.search(key, line):
            return line.rstrip()
        else:
            continue
    return ""


def SendHTML(toList, ccList, subject, content):
    msg = Message()
    chs = Charset('utf-8')
    chs.header_encode('True')
    msg['Mime-Version'] = '1.0'
    msg['Content-Type'] = 'text/html'
    msg['To'] = toList
    msg['CC'] = ccList
    msg['Subject'] = Header(subject, 'utf-8')
    msg['Date'] = email.Utils.formatdate()
    msg.set_payload(content, chs)
    smtp = smtplib.SMTP()
    smtp.connect("smtp-inc.alibaba-inc.com", "25")
    me = "speech-mailman@alibaba-inc.com"
    pwd = "spteam2015!"
    smtp.login(me, pwd)
    msg["From"] = "speech-mailman@alibaba-inc.com"
    smtp.sendmail(msg["From"], toList.split(',') + ccList.split(','), msg.as_string())
    smtp.quit()


def sendMail(filename, toList):
    print('Sending sendmail...')
    try:
        # toList = 'xiaocong.zouxc@alibaba-inc.com'
        content = open(filename).read()
        title = 'asr识别在线测试-%s' % (time.strftime('%Y%m%d %H:%M:%S'))
        SendHTML(toList, '', title, content)
        print('Sending sendmail done')
    except Exception, e:
        exstr = traceback.format_exc()
        print(exstr)
        sys.stderr.write('Sending sendmail error: ' + str(e) + '\n')


def sendMailWithContent(mailcontent, toList):
    print('Sending sendmail...')
    try:
        title = 'asr识别在线测试-%s' % (time.strftime('%Y%m%d %H:%M:%S'))
        SendHTML(toList, '', title, mailcontent)
        print('Sending sendmail done')
    except Exception, e:
        exstr = traceback.format_exc()
        asrpLogError(exstr)
        sys.stderr.write('Sending sendmail error: ' + str(e) + '\n')


def CreateMailContentOfRecognition(work_dir, oss_dir,body_list):
    tmp_dir = work_dir
    email_list = []
    result_file = os.path.join(work_dir, "result.txt")
    fr = open(result_file, "w+")
    html_style = '<style type="text/css"> .table { width: 100%; padding: 0; margin: 0; } th { font: bold 12px ' \
                 '"Trebuchet MS", Verdana, Arial, Helvetica, sans-serif; color: #4A4A4A; border-right: 1px solid #000;' \
                 ' border-bottom: 1px solid #000; border-top: 1px solid #000; letter-spacing: 2px; text-transform: ' \
                 'uppercase; text-align: left; padding: 6px 6px 6px 12px; background: #C5D9F1 no-repeat; }td ' \
                 '{ border-right: 1px solid #000; border-bottom: 1px solid #000; background: #fff; font-size:14px; ' \
                 'padding: 6px 6px 6px 12px; color: #4A4A4A; }th.spec,td.spec { border-left: 1px solid #000; }html>body ' \
                 'td{ font-size:14px;} tr.select th,tr.select td { background-color:#E6F2FB; color: #797268; } </style> '
    html_head = '<h5 style="text-align:center">asr在线识别结果</h5>'
    html_txt = '<h5 style="text-align:left">执行的服务器ip ： ' + socket.gethostbyname(
        socket.gethostname()) + '</h5><h5 style="text-align:left">执行目录 ： ' + tmp_dir + '</h5><body>'
    html_log = '<h5 style="text-align:left">详细日志已实时同步到： ' + oss_dir + ' ,请自行下载查看</h5><br/><h5 style="text-align:left">各测试集识别情况：</h5><body>'
    html_th = '<table  border="1px" cellspacing="0px" style="border-collapse:collapse" class="table" cellspacing="0"><tr> <th class="spec">测试集</th><th>执行的语音条数</th><th>字错误率 WER%</th><th>句错误率 SER%</th></tr> '
    fr.write(html_style + "\n" + html_head + html_txt + html_log + "\n" + html_th + "\n")
    fr.write(u''.join(body_list).encode('utf-8'))
    fr.write('</table></body>')
    fr.close()
    print("Results analysis is finished")


def GetKaldiResult(kaldifile):
    wer = ""
    ser = ""
    scored = ""
    if os.path.isfile(kaldifile):
        f = open(kaldifile)
        wer = asrpFindLineByKey(f, "%WER")
        ser = asrpFindLineByKey(f, "%SER")
        scored = asrpFindLineByKey(f, "Scored")
        f.close()
    w_len = len(wer.split(' '))
    if w_len>1:
        w = wer.split(' ')[1]
        s = ser.split(' ')[1]
        num = scored.split(' ')[1]
    else:
        w ="-"
        s ="-"
        num ="-"
    return w, s, num


def send_email(dir, oss_dir,test_case, email_recivers):
    body_txt = []
    wer, ser, count = GetKaldiResult(os.path.join(dir, test_case + "_compareResult.txt"))
    html_trtotal = '<tr><td class="spec">' + test_case + '</td><td>' + count + '</td><td>' + wer + '</td><td>' + ser + '</td></tr>'
    body_txt.append(html_trtotal)
    CreateMailContentOfRecognition(dir, oss_dir,body_txt)
    sendMail(os.path.join(dir, "result.txt"), email_recivers)


def send_email_recursion_dir(dir,oss_dir,email_recivers):
    body_txt = []
    files = os.listdir(dir)
    for f in files:
        if (f.endswith("compareResult.txt")):
            wer, ser, count = GetKaldiResult(os.path.join(dir, f))
            html_trtotal = '<tr><td class="spec">' + f + '</td><td>' + count + '</td><td>' + wer + '</td><td>' + ser + '</td></tr>'
            body_txt.append(html_trtotal)

    CreateMailContentOfRecognition(dir,oss_dir,body_txt)

    sendMail(os.path.join(dir, "result.txt"), email_recivers)


def main(argv):
    if (len(argv) != 5):
        print("Please enter dir asrFilePath markFilePath")
        return 0

    analy_result(argv[1], argv[2], argv[3], argv[4])


def main(argv):
    if (len(argv) == 5):
        dir = sys.argv[1]
        oss_dir=sys.argv[2]
        test_case = sys.argv[3]
        email_recivers = sys.argv[4]
        send_email(dir,oss_dir ,test_case, email_recivers)
    else:
        dir = sys.argv[1]
        oss_dir=sys.argv[2]
        email_recivers = sys.argv[3]
        send_email_recursion_dir(dir, oss_dir,email_recivers)


if __name__ == "__main__":
    main(sys.argv)
