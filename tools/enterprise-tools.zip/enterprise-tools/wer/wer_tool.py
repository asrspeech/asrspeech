#! /usr/bin/env python
# -*- coding: utf-8 -*-
# *************************************************************
# Filename @ wer_tool.py
# Create date @ 2018-01-28 20:13:11
# Description @
# *************************************************************
import os
import re
import stat
import Queue
import subprocess
import platform
import threading
import random
import sys
import tarfile


def asrpChmodAddExecute(file):
    st = os.stat(file)
    os.chmod(file, st.st_mode | stat.S_IEXEC)


def asrpReadlines(std, queue, str):
    queue.put({str: "".join(std.readlines())})


def asrpIsOSLinux():
    return (platform.system() == "Linux")


def asrpExecuteCommand(cmd, extrapopencmd={}):
    saved_LD_LIBRARY_PATH = ""
    q = Queue.Queue()
    kwargs = {'shell': True, 'stdin': subprocess.PIPE, 'stdout': subprocess.PIPE, 'stderr': subprocess.PIPE}
    kwargs.update(extrapopencmd)
    if asrpIsOSLinux():
        exe = (cmd.split())[0]
        env = os.environ
        env["LD_LIBRARY_PATH"] = os.path.dirname(os.path.abspath(exe))
        kwargs.update({"env": env})
    p = subprocess.Popen(cmd, **kwargs)
    (child_stdin, child_stdout, child_stderr) = (p.stdin, p.stdout, p.stderr)
    cmdforlog = cmd
    cmdforlog = re.sub("\-\-id=\S+", "--id=HIDE", cmdforlog)
    cmdforlog = re.sub("\-\-key=\S+", "--key=HIDE", cmdforlog)
    cmdforlog = re.sub("\-u \S+", "-u HIDE", cmdforlog)
    cmdforlog = re.sub("\-p \S+", "-p HIDE", cmdforlog)
    # print("execute:\n" + cmdforlog + "\n")
    threads = []
    str_out = ""
    str_err = ""
    threads.append(threading.Thread(target=asrpReadlines, args=(child_stdout, q, "str_out")))
    threads.append(threading.Thread(target=asrpReadlines, args=(child_stderr, q, "str_err")))
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    while not q.empty():
        for key, value in q.get().items():
            if "str_out" == key:
                str_out = value
            elif "str_err" == key:
                str_err = value
            else:
                print ("wrong queue item")
            break;
    child_stdout.close()
    child_stderr.close()
    randid = random.randint(1, 100000000)
    # if len(str_out) > 0:
    # print("<output><id>" + str(
    #     randid) + "</id><command>" + cmdforlog.decode('utf8') + "</command><message>" + str_out.decode(
    #     'utf8') + "</message></output>\n")
    # if len(str_err) > 0:
    # print("<error><id>" + str(
    #    randid) + "</id><command>" + cmdforlog.decode('utf8') + "</command><message>" + str_err.decode(
    #   'utf8') + "</message></error>\n")
    returncode = p.wait()
    return (str_out, str_err, returncode)


def KaldiCompare(asrFormat_path, transFormat_path, kaldiResult_file):
    sys = platform.system()
    if "Linux" in sys:
        compute = "compute-wer4"
    else:
        compute = "compute-mac"

    script_path = os.path.split(os.path.realpath(__file__))[0]  # 当前脚本文件所在目录位置
    asrpChmodAddExecute(os.path.join(script_path, compute))
    cmdline = (os.path.join(script_path,
                            compute) + '  --text --mode="present" ark:' + transFormat_path + ' ark:' + asrFormat_path + ' ' + kaldiResult_file)
    (str_out, str_err, returncode) = asrpExecuteCommand(cmdline)
    if returncode != 0:
        print "kaldi compare failed " + str(cmdline)
    fp = open(kaldiResult_file, "a")
    fp.write(str_out)
    fp.close()


def numFormat(line):
    line = re.sub(u'一', u'1', line)
    line = re.sub(u'二', u'2', line)
    line = re.sub(u'三', u'3', line)
    line = re.sub(u'四', u'4', line)
    line = re.sub(u'五', u'5', line)
    line = re.sub(u'六', u'6', line)
    line = re.sub(u'七', u'7', line)
    line = re.sub(u'八', u'8', line)
    line = re.sub(u'九', u'9', line)
    line = re.sub(u'零', u'0', line)
    line = re.sub(u'幺', u'1', line)
    return line

re_words = re.compile(u"[\u4e00-\u9fa5]+")
def fileFormat(old_file, new_file):
    # print "Convert the format of the file %s" % old_file
    """
    格式化识别结果文档和标注结果文档，格式化内容包括：
    1、将文档格式由 "171340e_0_3=嗯嗯" 更新为 "171340e_0_3 嗯 嗯",以满足kaldi对比格式
    2、统一文档中的数字格式，如文档中可能存在阿拉伯数字以及中文数字，现统一替换为阿拉伯数字
    3、统一文档中的英文大小写，将英文全部统一成小写
    4、去掉所有中英文标点符号
    :param old_file:格式化前的文件
    :param new_file:格式化后的文件，若不存在则新建，若存在则替换
    :return:
    """
    fo = open(old_file)
    fn = open(new_file, 'w')
    for line in fo:
        res = re.findall(re_words, line.decode('utf-8'))       # 查询出所有的中文
        if res:
            line = numFormat(line.strip().decode('utf8'))
            lines = []
            if "=" in line:
                li = line.split("=")
                name=re.sub(r'.wav$', '', li[0])
                name=re.sub(r'.pcm$', '', name)
                lines.append(name.strip())
                value = li[1].replace('\r\n', '').replace('\n', '').replace(' ', '').replace('!', '') \
                    .replace('！'.decode('utf8'), '').replace('?', '').replace('？'.decode('utf8'), '').replace(
                    '、'.decode('utf8'), '') \
                    .replace('。'.decode('utf8'), '').replace(',', '').replace('，'.decode('utf8'), '').replace('.', '')
                lines.append(value)
                fn.write("%s" % lines[0].encode('utf8'))
                lines.pop(0)
            elif "\t" in line:
                lines = line.split("\t")
                left = re.sub(r'^wav\d*_\d*_', '', lines[0])
                fn.write("%s" % left.encode('utf8'))
                lines.pop(0)
            else:
                str_list = line.split(" ")
                name_key = str_list.replace("wav[0-9]*_[0-9]*_", '')
                left_str = name_key.strip()
                right_str = "".join(str_list[1:])
                value = right_str.replace('\r\n', '').replace('\n', '').replace(' ', '').replace('!', '') \
                    .replace('！'.decode('utf8'), '').replace('?', '').replace('？'.decode('utf8'), '').replace(
                    '、'.decode('utf8'), '') \
                    .replace('。'.decode('utf8'), '').replace(',', '').replace('，'.decode('utf8'), '').replace('.', '')

                fn.write("%s" % left_str.encode('utf8'))
                lines.append(value)

            for word in lines:
                for char in word:
                    fn.write(" %s" % char.encode('utf8').strip().lower())
            fn.write("\n")
        else:
            line = line.strip().replace("=", ' ').replace("\t", ' ').strip()
            fn.write(line)
            fn.write("\n")
    fn.close()
    fo.close()

def analy_result(dir, asr_file, mark_file, case_name):
    asr_format = case_name + "_asr_format.txt"
    mark_format = case_name + "_mark_format.txt"
    asrFormat_path = os.path.join(dir, asr_format)
    transFormat_path = os.path.join(dir, mark_format)


    fileFormat(asr_file, asrFormat_path)
    fileFormat(mark_file, transFormat_path)

    # starting analyse asr result by kaldi
    compareResult_path = os.path.join(dir, case_name + "_compareResult.txt")
    KaldiCompare(asrFormat_path, transFormat_path, compareResult_path)



def make_targz(output_filename, source_dir):
    """
    一次性打包整个根目录。空子目录会被打包。
    如果只打包不压缩，将"w:gz"参数改为"w:"或"w"即可。
    """
    with tarfile.open(output_filename, "w:gz") as tar:
        tar.add(source_dir, arcname=os.path.basename(source_dir))


def asrpFindLineByKey(file_content, key):
    for line in file_content:
        if re.search(key, line):
            return line.rstrip()
        else:
            continue
    return ""


def getKaldiResult(kaldifile):
    wer = ""
    ser = ""
    scored = ""
    if os.path.isfile(kaldifile):
        f = open(kaldifile)
        wer = asrpFindLineByKey(f, "%WER")
        ser = asrpFindLineByKey(f, "%SER")
        scored = asrpFindLineByKey(f, "Scored")
        f.close()
        w_len = len(wer.split(' '))
        if w_len > 1:
            w = wer.split(' ')[1]
            s = ser.split(' ')[1]
            num = scored.split(' ')[1]
        else:
            w = "-"
            s = "-"
            num = "-"
    print ("%s # %s # %s" % (w, s, num))
    return w, s, num


def get_wer_body(dir, test_case):
    file = os.path.join(dir, test_case + "_compareResult.txt")
    wer, ser, count = getKaldiResult(file)
    return wer


def writeResultFile(dir, key, value):
    result_file = os.path.join(dir, "summary.txt")
    fo = open(result_file, "a")
    str = key + " :" + value;
    fo.write(str)
    fo.close()


def main(argv):
    """
    需要输入四个参数
    最终输出路径，asr结果文本，标注文本，用例名字
    打包文件为 最终输出路径/用例名字.tar.gz
    """
    if (len(argv) != 5):
        print("Please enter dir asrFilePath markFilePath case_name")
        return 0

    try:
        analy_result(argv[1], argv[2], argv[3], argv[4])
        wer = get_wer_body(argv[1], argv[4])
        writeResultFile(argv[1], argv[4], wer)
    except:
        sys.exit(-1)


if __name__ == "__main__":
    main(sys.argv)
