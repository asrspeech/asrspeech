#!/bin/sh
##########################################
#输入一个文件列表list，获得识别结果
# 运行完毕，在logs/下面会为每一个录音文件生成2个识别结果文件： xxx.json.txt是服务端返回的原始json格式文本，xxx.txt是解析后保持的识别结果
##########################################

#服务端地址,为gateway服务的地址，默认为127.0.0.1
url=http://127.0.0.1:8101/stream/v1/filetrans
appkey=default
token=default

#录音文件列表，每行一个录音文件地址，支持本地文件或http下载地址，可参考示例demo.list的格式规范。注意该路径一定是文件转写服务可以访问到的地址。
#若有一批本地录音文件，则可以将其放到nls-cloud-filetrans所在机器上的service/data/servicedata/nls-filetrans/下面，
# 比如有 1.wav，则可以在demo中设置路径为：file:/home/admin/nls-filetrans/disk/1.wav
filelist=demo.list

### 以下参数按实际需要开启或者关闭 ###
#是否开启智能分轨（只⽀持8000Hz采样率单通道语⾳）
auto_split=true
#是否给句子加标点
enable_punctuation_prediction=true
#是否打开ITN，中⽂数字将转为阿拉伯数字输出
enable_inverse_text_normalization=true
# 是否打开文本顺滑
enable_disfluency=false
# 是否开启语义断句, 注意！语义断句参数enable_semantic_sentence_detection和智能分轨参数auto_split不可同时为true
enable_semantic_sentence_detection=false
# 是否将⼤于16kHz采样率的⾳频进⾏⾃动降采样
enable_sample_rate_adaptive=true
# 是否开启返回词信息
enable_words=false

# vad断句最大间隔，有效值[200, 2000], 此处为0表示客户端不设置
max_end_silence=0
# 允许单句话最⼤结束静⾳时间，此处为0表示客户端不设置
max_single_segment_time=0

# 定制语言模型id，此处为no表示客户端不设置
customization_id=no
# 定制声学模型id，此处为no表示客户端不设置
als_am_id=no
# 定制泛热词id，此处为no表示客户端不设置
vocabulary_id=no
# 定制类热词(人名类热词)，此处为no表示客户端不设置
class_vocabulary_id_for_person=no
# 定制类热词(地名类热词)，此处为no表示客户端不设置
class_vocabulary_id_for_address=no


java -jar nls-test-filetrans.jar --url ${url} --appkey ${appkey} --token ${token} --filelist ${filelist} \
  --auto_split ${auto_split} \
  --enable_punctuation_prediction ${enable_punctuation_prediction} \
  --enable_inverse_text_normalization ${enable_inverse_text_normalization} \
  --enable_disfluency ${enable_disfluency} \
  --enable_semantic_sentence_detection ${enable_semantic_sentence_detection} \
  --enable_sample_rate_adaptive ${enable_sample_rate_adaptive} \
  --enable_words ${enable_words} \
  --max_end_silence ${max_end_silence} \
  --max_single_segment_time ${max_single_segment_time} \
  --customization_id ${customization_id} \
  --als_am_id ${als_am_id} \
  --vocabulary_id ${vocabulary_id} \
  --class_vocabulary_id_for_person ${class_vocabulary_id_for_person} \
    --class_vocabulary_id_for_address ${class_vocabulary_id_for_address}

