#!/bin/sh

##########################################
#输入一个本地音频路径，获得识别结果
# 运行完毕，在logs/text.log文件中是所有识别结果
##########################################

#服务地址,为gateway服务的地址，端口号默认是8010
host=ws://127.0.0.1:8101/ws/v1


#音频路径,注意必须是一个路径，该路径下包含了音频文件,递归目录及子目录所有文件
wav_path=data/sound/wav

#并发数
thread_num=10
#采样率
sample_rate=8000

#实时长语音为realtime，短语音为asr
module=realtime


#############################
# 以下参数，根据实际需求进行修改  #
#############################
#vad后端点长度，-1为关闭vad，0为使用服务端默认配置
silence=0
#泛热词id，默认不使用填写为no
vocab_id=no
#类热词id
slot_id=no
#定制LM模型id
custom_lm_id=no
#定制AM模型id
custom_am_id=no

#是否打开语义断句
enable_semantic_sentence_detection=false


#是否加标点
enPunctuation=true
#是否返回中间识别结果
en_inter=true
#是否将汉字转为阿拉伯数字
en_itn=true



do_asr(){
    if [ "$sample_rate" == "16000" ];then
        package_len=3200
        sleep_time=100
    elif [ "$sample_rate" == "8000" ];then
        package_len=3200
        sleep_time=200
    fi
java -jar auto-test-suite.jar -option all -moduleName ${module} \
-host ${host} -filePath ${wav_path} \
-threadNum ${thread_num} -runTimes 1 \
-packageLen ${package_len} -sleepTime ${sleep_time} \
-sampleRate ${sample_rate} -maxSilence ${silence} \
-enPunctuation ${enPunctuation} \
-vocabId ${vocab_id} -classVocabId ${slot_id} \
-lmId ${custom_lm_id} -amId ${custom_am_id} \
-appKey default -token default  \
-enableSemanticSentenceDetection ${enable_semantic_sentence_detection} -interResult ${en_inter} -bItn ${en_itn}

}

rm -rf logs/*
do_asr
