#!/bin/bash
#!/bin/sh

###################################
#输入一个本地路径，该路径下可以有多个文本文件
#根据设置的循环次数，循环进行tts
###################################

if [ $# -lt 3 ]; then
    echo "usage: " $0 \<voice-name\> \<thread_num\> \<run_times\>
    exit
fi

#服务地址
host=ws://127.0.0.1:8101/ws/v1
#测试文件
file_path=30_chinese_charactors.txt
#并发数
thread_num=$2
#每线程运行次数
run_times=$3
#采样率
sample_rate=8000
#音量
volume=50
#语速（-500 500）
speechrate=0
#音速（-500 500）
pitchrate=0
#发音人
voice=$1
#合成方式 （0-3）
method=0
#appkey
appkey=default
token=default
#格式
encode_type=wav
#压测过程中是否保存音频文件
save_file=false
#压测过程中是否跑完所有文本，默认false是随机选取文本
perf_all=false
#是否开启时间戳
enable_subtitle=false
#是否开启RTF指标，只有此值为true且encode_type为wav时，才会输出此指标
enable_rtf=true
#true: 客服场景，音频合成结果会根据音频播放时长等待，后继续发送数据包/false:请求连续发送，无等待
customer_scene=false

do_tts(){
  java -jar tts-perf.jar -option perf -moduleName tts \
          -host ${host} -filePath ${file_path} \
          -threadNum ${thread_num} -runTimes ${run_times}\
            -ttsSampleRate ${sample_rate} \
            -volume ${volume} \
            -speechRate ${speechrate}\
            -pitchRate ${pitchrate}\
            -voice ${voice}\
            -appKey ${appkey} -token ${token}\
            -method ${method} -enableRTF ${enable_rtf} -customerScene ${customer_scene} \
            -encodeType ${encode_type} -enableSubtitle ${enable_subtitle} -saveFile ${save_file}
}
do_tts &

#nohup sar -u 30 20 >> cpu_${voice}_${thread_num}.log &
#nohup sar -r 30 20 >> mem_${voice}_${thread_num}.log &
