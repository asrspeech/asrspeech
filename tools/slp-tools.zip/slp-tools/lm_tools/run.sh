#!/bin/bash

if [ $# -lt 2 ]; then
  echo "$0 lm_path lmvocab_path"
  exit
fi

lm_path=$1
lmvocab_path=$2

work_dir=`pwd`
echo "${work_dir}"

export LD_LIBRARY_PATH=${work_dir}/lm_tools/lib

./lm_tools/extract_lmvocab_from_lm --lm-format=ngram ${lm_path} ${lmvocab_path}
