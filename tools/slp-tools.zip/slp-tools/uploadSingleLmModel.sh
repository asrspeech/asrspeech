java -jar nls-cloud-tools-slp.jar \
--type=uploadSingleLmModel \
--host=*** \
--token=*** --user-id=*** \
--single-lm-model-path=***  --lm-base-id=***
