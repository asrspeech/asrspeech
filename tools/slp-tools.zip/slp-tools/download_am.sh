java -jar nls-cloud-tools-slp.jar \
--type=download \
--host=*** \
--token=*** --user-id=*** \
--download-am-model=true --am-model-id=***
