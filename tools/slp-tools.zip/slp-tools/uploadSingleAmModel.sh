java -jar nls-cloud-tools-slp.jar \
--type=uploadSingleAmModel \
--host=*** \
--token=*** --user-id=*** \
--single-am-model-path=***  --am-base-id=***
