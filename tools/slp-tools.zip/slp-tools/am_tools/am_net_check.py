# -*- coding: utf-8 -*-
# Usage:
#     check the structure of 2 am.net file

import sys
import os
import stat
import subprocess

__author__ = 'jiangyu.xzy'


def am_net_check(nnet_info_path, net1, net2):
    if not os.path.exists(net1) or not os.path.exists(net2):
        print("am net not exists!")
        return False
    if not os.path.exists(nnet_info_path):
        print("nnet_info not exists!")
        return False
    st = os.stat(nnet_info_path)
    os.chmod(nnet_info_path, st.st_mode | stat.S_IEXEC)
    cmd1 = nnet_info_path + " " + net1
    p1 = subprocess.Popen(cmd1, shell=True, stdout=subprocess.PIPE)
    cmd2 = nnet_info_path + " " + net2
    p2 = subprocess.Popen(cmd2, shell=True, stdout=subprocess.PIPE)
    struct1 = []
    struct2 = []
    for line1 in p1.stdout.read().split('\n'):
        if line1.startswith('component'):
            struct1.append(line1)
    for line2 in p2.stdout.read().split('\n'):
        if line2.startswith('component'):
            struct2.append(line2)
    if len(struct1) != len(struct2):
        return False
    else:
        for i in xrange(len(struct1)):
            if struct1[i].strip() != struct2[i].strip():
                return False
        return True


if __name__ == "__main__":
    usage = "USAGE: python nnet_info_path am_net_check.py am1.net am2.net"
    if len(sys.argv) != 4:
        print(usage)
        exit(-1)
    nnet_info_path = sys.argv[1]
    net1 = sys.argv[2]
    net2 = sys.argv[3]

    result = am_net_check(nnet_info_path, net1, net2)
    print("am net check over!")
    if result:
        print("%s and %s have SAME nnet structure!" % (net1, net2))
    else:
        print("%s and %s NOT have same nnet structure! or net not exist" % (net1, net2))
