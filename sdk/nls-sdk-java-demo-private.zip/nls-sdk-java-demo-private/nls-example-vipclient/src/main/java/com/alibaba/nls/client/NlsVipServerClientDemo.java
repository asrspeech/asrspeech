package com.alibaba.nls.client;

import java.io.InputStream;

import com.alibaba.nls.client.protocol.InputFormatEnum;
import com.alibaba.nls.client.protocol.SampleRateEnum;
import com.alibaba.nls.client.protocol.asr.SpeechTranscriber;
import com.alibaba.nls.client.protocol.asr.SpeechTranscriberListener;
import com.alibaba.nls.client.protocol.asr.SpeechTranscriberResponse;

public class NlsVipServerClientDemo {
    public static void main(String[] args) throws Exception {
        if (args.length < 3) {
            System.err.println("NlsVipServerClientDemo need params: <vipServer> <vipKey> <token>  ");
            System.exit(-1);
        }

        String vipServer = args[0];
        String vipKey = args[1];
        String token = args[2];

        System.out.println("vipServer is:"+vipServer+",vipKey is "+vipKey+",token is :"+token);

        NlsVipServerClient client = new NlsVipServerClient(vipServer, vipKey, token);
        SpeechTranscriber transcriber = new SpeechTranscriber(client, new SpeechTranscriberListener() {
            //识别出中间结果.服务端识别出一个字或词时会返回此消息.仅当setEnableIntermediateResult(true)时,才会有此类消息返回
            @Override
            public void onTranscriptionResultChange(SpeechTranscriberResponse response) {
                System.out.println("name: " + response.getName() +
                    //状态码 20000000 表示正常识别
                    ", status: " + response.getStatus() +
                    //句子编号，从1开始递增
                    ", index: " + response.getTransSentenceIndex() +
                    //当前的识别结果
                    ", result: " + response.getTransSentenceText() +
                    //当前已处理的音频时长，单位是毫秒
                    ", time: " + response.getTransSentenceTime());
            }

            @Override
            public void onTranscriberStart(SpeechTranscriberResponse response) {
                System.out.println("task_id: " + response.getTaskId() +
                    "name: " + response.getName() +
                    ", status: " + response.getStatus());
            }

            @Override
            public void onSentenceBegin(SpeechTranscriberResponse response) {
                System.out.println("task_id: " + response.getTaskId() +
                    "name: " + response.getName() +
                    ", status: " + response.getStatus());
            }

            //识别出一句话.服务端会智能断句,当识别到一句话结束时会返回此消息
            @Override
            public void onSentenceEnd(SpeechTranscriberResponse response) {
                System.out.println("name: " + response.getName() +
                    //状态码 20000000 表示正常识别
                    ", status: " + response.getStatus() +
                    //句子编号，从1开始递增
                    ", index: " + response.getTransSentenceIndex() +
                    //当前的识别结果
                    ", result: " + response.getTransSentenceText() +
                    //置信度
                    ", confidence: " + response.getConfidence() +
                    //开始时间
                    ", begin_time: " + response.getSentenceBeginTime() +
                    //当前已处理的音频时长，单位是毫秒
                    ", time: " + response.getTransSentenceTime());
            }

            //识别完毕
            @Override
            public void onTranscriptionComplete(SpeechTranscriberResponse response) {
                System.out.println("name: " + response.getName() +
                    ", status: " + response.getStatus());
            }

            @Override
            public void onFail(SpeechTranscriberResponse response) {
                System.out.println(
                    "task_id: " + response.getTaskId() +
                        //状态码 20000000 表示识别成功
                        ", status: " + response.getStatus() +
                        //错误信息
                        ", status_text: " + response.getStatusText());
            }
        });
        //专有云appkey=default
        transcriber.setAppKey("default");
        //输入音频编码方式
        transcriber.setFormat(InputFormatEnum.PCM);
        //输入音频采样率
        transcriber.setSampleRate(SampleRateEnum.SAMPLE_RATE_16K);
        transcriber.start();
        InputStream ins = NlsVipServerClientDemo.class.getResourceAsStream("/nls-sample-16k.wav");
        transcriber.send(ins);
        transcriber.stop();
        client.shutdown();
    }
}
