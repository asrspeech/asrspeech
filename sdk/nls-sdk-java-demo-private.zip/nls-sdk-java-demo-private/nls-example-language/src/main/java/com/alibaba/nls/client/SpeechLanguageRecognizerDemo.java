package com.alibaba.nls.client;

import java.io.File;
import java.io.FileInputStream;

import com.alibaba.nls.client.protocol.NlsClient;
import com.alibaba.nls.client.protocol.commonrequest.CommonRequest;
import com.alibaba.nls.client.protocol.commonrequest.CommonRequestListener;
import com.alibaba.nls.client.protocol.commonrequest.CommonRequestResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 此示例演示了
 *      实时语种识别功能
 *      通过本地模拟实时流发送
 * (仅作演示，需用户根据实际情况实现)
 */
public class SpeechLanguageRecognizerDemo {
    private String appKey;
    private NlsClient client;

    private static final Logger logger = LoggerFactory.getLogger(SpeechLanguageRecognizerDemo.class);

    public SpeechLanguageRecognizerDemo(String appKey, String token, String url) {
        this.appKey = appKey;
        //TODO 重要提示 创建NlsClient实例,应用全局创建一个即可,生命周期可和整个应用保持一致,默认服务地址为阿里云线上服务地址
        if(url.isEmpty()) {
            client = new NlsClient(token);
        }else {
            client = new NlsClient(url, token);
        }
    }

    private static CommonRequestListener getListener() {
        CommonRequestListener listener = new CommonRequestListener() {
            @Override
            public void onStarted(CommonRequestResponse response) {
                System.out.println("[" + response.getTaskId() + "] task started: " + response.getName());
            }

            @Override
            public void onEvent(CommonRequestResponse response) {
                System.out.println("[" + response.getTaskId() + "] event: " + response.getName() + ", payload: " + response.payload);
            }

            @Override
            public void onStopped(CommonRequestResponse response) {
                System.out.println("[" + response.getTaskId() + "] task stopped: " + response.getName());
            }

            @Override
            public void onFailed(CommonRequestResponse response) {
                System.out.println("[" + response.getTaskId() + "] task failed: " + response.getName() +
                    ", status code: " + response.getStatus() + ", " + response.getStatusText());
            }
        };

        return listener;
    }

    /// sampleRate 仅支持8000或16000
    public static int getSleepDelta(int dataSize, int sampleRate) {
        // 仅支持16位采样
        int sampleBytes = 16;
        // 仅支持单通道
        int soundChannel = 1;
        return (dataSize * 10 * 8000) / (160 * sampleRate);
    }

    public void process(String filepath) {
        CommonRequest commonRequest = null;
        try {
            CommonRequestListener listener = getListener();
            commonRequest = new CommonRequest(client, listener, "LanguageIdentification");
            commonRequest.setAppKey(appKey);
            commonRequest.addCustomedParam("format", "pcm");
            commonRequest.addCustomedParam("sample_rate", 16000);

            commonRequest.start();
            File file = new File(filepath);
            FileInputStream fis = new FileInputStream(file);
            byte[] b = new byte[3200];
            int len;
            while ((len = fis.read(b)) > 0) {
                logger.info("send data pack length: " + len);
                commonRequest.send(b);
                // TODO  重要提示：这里是用读取本地文件的形式模拟实时获取语音流并发送的，因为read很快，所以这里需要sleep
                // TODO  如果是真正的实时获取语音，则无需sleep, 如果是8k采样率语音，第二个参数改为8000
                // 8000采样率情况下，3200byte字节建议 sleep 200ms，16000采样率情况下，3200byte字节建议 sleep 100ms
                int deltaSleep = getSleepDelta(len, 8000);
                Thread.sleep(deltaSleep);
            }

            //通知服务端语音数据发送完毕,等待服务端处理完成
            long now = System.currentTimeMillis();
            logger.info("wait for complete");
            commonRequest.stop();
            logger.info("latency : " + (System.currentTimeMillis() - now) + " ms");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if(commonRequest != null) {
                commonRequest.close();
            }
        }
    }

    public void shutdown() {
        client.shutdown();
    }

    public static void main(String[] args) throws Exception {
        // 专有云情况下appkey和token默认即为default，且不可修改
        String appKey = "default";
        String token = "default";

        // TODO 请修改为实际专有云环境下的ip地址，比如 ws://127.0.0.1:8101/ws/v1, 格式：ip:port 即为单机版情况下gateway的ip：port
        String url = "ws://ip:port/ws/v1";

        // TODO 重要提示： 这里用一个本地文件来模拟发送实时流数据，实际使用时，用户可以从某处实时采集或接收语音流并发送到ASR服务端
        String filepath = "nls-sample-16k.wav";
        SpeechLanguageRecognizerDemo demo = new SpeechLanguageRecognizerDemo(appKey, token, url);

        demo.process(filepath);
        demo.shutdown();
    }
}
