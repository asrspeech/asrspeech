package com.alibaba.nls.client;

import com.alibaba.nls.client.protocol.InputFormatEnum;
import com.alibaba.nls.client.protocol.NlsClient;
import com.alibaba.nls.client.protocol.SampleRateEnum;
import com.alibaba.nls.client.protocol.NlsClient;
import com.alibaba.nls.client.protocol.commonrequest.CommonRequest;
import com.alibaba.nls.client.protocol.commonrequest.CommonRequestListener;
import com.alibaba.nls.client.protocol.commonrequest.CommonRequestResponse;

import com.alibaba.nls.client.util.OpuCodec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.concurrent.CountDownLatch;

public class SpeechLanguageRecognizerMultiDemo {
    private static final Logger logger = LoggerFactory.getLogger(SpeechLanguageRecognizerMultiDemo.class);

    /// 根据二进制数据大小计算对应的同等语音长度
    /// sampleRate 仅支持8000或16000
    public static int getSleepDelta(int dataSize, int sampleRate) {
        // 仅支持16位采样
        int sampleBytes = 16;
        // 仅支持单通道
        int soundChannel = 1;
        return (dataSize * 10 * 8000) / (160 * sampleRate);
    }

    private static CommonRequestListener getListener() {
        CommonRequestListener listener = new CommonRequestListener() {
            @Override
            public void onStarted(CommonRequestResponse response) {
                System.out.println("[" + response.getTaskId() + "] task started: " + response.getName());
            }

            @Override
            public void onEvent(CommonRequestResponse response) {
                System.out.println("[" + response.getTaskId() + "] event: " + response.getName() + ", payload: " + response.payload);
            }

            @Override
            public void onStopped(CommonRequestResponse response) {
                System.out.println("[" + response.getTaskId() + "] task stopped: " + response.getName());
            }

            @Override
            public void onFailed(CommonRequestResponse response) {
                System.out.println("[" + response.getTaskId() + "] task failed: " + response.getName() +
                        ", status code: " + response.getStatus() + ", " + response.getStatusText());
            }
        };

        return listener;
    }

    static class Task implements Runnable {
        private String appKey;
        private NlsClient client;
        private CountDownLatch latch;
        private String audioFile;
        private boolean isOpuEncode;

        public Task(String appKey, NlsClient client, CountDownLatch latch, String audioFile, boolean isOpuEncode) {
            this.appKey = appKey;
            this.client = client;
            this.latch = latch;
            this.audioFile = audioFile;
            this.isOpuEncode = isOpuEncode;
        }

        @Override
        public void run() {
            CommonRequest commonRequest = null;
            try {
                CommonRequestListener listener = getListener();
                commonRequest = new CommonRequest(client, listener, "LanguageIdentification");
                commonRequest.setAppKey(appKey);
                commonRequest.addCustomedParam("format", "pcm");
                commonRequest.addCustomedParam("sample_rate", 16000);

                commonRequest.start();
                File file = new File(audioFile);
                FileInputStream fis = new FileInputStream(file);
                byte[] b = new byte[3200];
                int len;
                while ((len = fis.read(b)) > 0) {
                    logger.info("send data pack length: " + len);
                    commonRequest.send(b);
                    // TODO  重要提示：这里是用读取本地文件的形式模拟实时获取语音流并发送的，因为read很快，所以这里需要sleep
                    // TODO  如果是真正的实时获取语音，则无需sleep, 如果是8k采样率语音，第二个参数改为8000
                    // 8000采样率情况下，3200byte字节建议 sleep 200ms，16000采样率情况下，3200byte字节建议 sleep 100ms
                    int deltaSleep = getSleepDelta(len, 16000);
                    Thread.sleep(deltaSleep);
                }

                //通知服务端语音数据发送完毕,等待服务端处理完成
                long now = System.currentTimeMillis();
                logger.info("wait for complete");
                commonRequest.stop();
                logger.info("latency : " + (System.currentTimeMillis() - now) + " ms");
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if(commonRequest != null) {
                    commonRequest.close();
                }
                latch.countDown();
            }
        }
    }

    public static void main(String[] args) {
        // 专有云情况下appkey和token默认即为default，且不可修改
        String appKey = "default";
        String token = "default";

        // TODO 请修改为实际专有云环境下的ip地址，比如 ws://127.0.0.1:8101/ws/v1, 格式：ip:port 即为单机版情况下gateway的ip：port
        String url = "ws://ip:port/ws/v1";

        String audioFile = "./nls-sample-16k.wav";
        int threadNum    = 4;

        final NlsClient client = new NlsClient(url, token);
        CountDownLatch latch = new CountDownLatch(threadNum);

        try {
            for (int i = 0; i < threadNum; i++) {
                Task task = new Task(appKey, client, latch, audioFile, false);
                new Thread(task).start();
            }
            latch.await();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            client.shutdown();
        }
    }
}
